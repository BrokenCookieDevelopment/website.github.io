var darkThemeBtn = document.getElementById('darkThemeBtn');
var isThemeDark = false;


var purchaseBtn = document.getElementById('purchaseBtn');


//The variables for the text colors
var p = document.getElementsByTagName("p");
var h1 = document.getElementsByTagName("h1");
var h2 = document.getElementsByTagName("h2");
var h3 = document.getElementsByTagName("h3");
var h4 = document.getElementsByTagName("h4");
var h5 = document.getElementsByTagName("h5");
var h6 = document.getElementsByTagName("h6 ");





$(document).ready(function(){
	$('#darkThemeBtn').click(function(){
		ChangeTheme();
	});
});










function ChangeTheme()
{
	darkThemeBtn.classList.toggle(".dark-mode");

	// if (isThemeDark != true) {
	// 	isThemeDark = true;
	// 	darkThemeBtn.innerHTML = "Dark Theme: ON";
	// 	//DarkThemeColors();
	// }
	// else{
	// 	isThemeDark = false;
	// 	darkThemeBtn.innerHTML = "Dark Theme: OFF";
	// 	//DefaultThemeColors();
	// }
}


function DarkThemeColors()
{
	h3.style.color = 'blue';
}

function DefaultThemeColors()
{

}