$(document).ready(function () {
	$("#submit").click(function () {
		alert("Message Sent");
	})
});